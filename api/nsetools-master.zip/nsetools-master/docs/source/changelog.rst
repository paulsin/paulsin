Release History & Change Log
=============================

0.1.0 : First release.

0.2.0 : First stable release.

1.0.0 : Support for both Python2 and Python3

1.0.1 : Few bug fixes to address format changes.

1.0.3 : Fixed encoding bug. End of offical python 2 support.

1.0.5 : Handled url format change in nseindia website

1.0.6 : Fixed the bug related to "negative change" in stock price.

1.0.7 : Added support for getting F&O lot sizes.

1.0.8 : Few build issues.

1.0.10: Handling change in backend data format.

1.0.11: Updated URLs after NSE website changes.
